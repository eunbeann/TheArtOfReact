import React from 'react';
import PostViewer from '../components/post/PostViewer';

const PostPage = () => {
        return (
        <>
            <PostViewer />
        </>
        )
};

export default PostPage;
